export const metadata = {
  title: 'Shamba Agronomist',
  description: 'Digital agronomist and marketplace for Kenyan farmers',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: 'system-ui, sans-serif', margin: 0, background: '#f4f7f2' }}>
        {children}
      </body>
    </html>
  );
}
