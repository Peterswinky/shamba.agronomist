'use client';
import { useEffect, useState } from 'react';
import { api } from '../lib/api';

export default function SoilAdvisor() {
  const [soilTypes, setSoilTypes] = useState([]);
  const [soilType, setSoilType] = useState('');
  const [acreage, setAcreage] = useState(1);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.soilTypes().then((r) => {
      setSoilTypes(r.soilTypes);
      setSoilType(r.soilTypes[0]);
    });
  }, []);

  async function getAdvice() {
    setError('');
    setLoading(true);
    try {
      const r = await api.soilAdvise({ soilType, acreage: Number(acreage) });
      setResult(r);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  const presets = [0.25, 0.5, 1, 2, 5];

  return (
    <div style={{ maxWidth: 640, margin: '40px auto', padding: 24 }}>
      <h1 style={{ color: '#2e6b34' }}>🌱 Soil Advisor</h1>
      <p style={{ color: '#666' }}>Select your soil type and land size to get crop and yield recommendations.</p>

      <div style={{ background: '#fff', padding: 20, borderRadius: 12, marginTop: 16 }}>
        <label style={{ fontWeight: 600 }}>Soil Type</label>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, margin: '10px 0' }}>
          {soilTypes.map((t) => (
            <button
              key={t}
              onClick={() => setSoilType(t)}
              style={{
                padding: '8px 14px', borderRadius: 20, border: '1px solid #2e6b34',
                background: soilType === t ? '#2e6b34' : '#fff',
                color: soilType === t ? '#fff' : '#2e6b34', cursor: 'pointer',
              }}
            >
              {t}
            </button>
          ))}
        </div>

        <label style={{ fontWeight: 600 }}>Land size (acres)</label>
        <div style={{ display: 'flex', gap: 8, margin: '10px 0' }}>
          {presets.map((p) => (
            <button
              key={p}
              onClick={() => setAcreage(p)}
              style={{
                padding: '8px 14px', borderRadius: 8, border: '1px solid #ccc',
                background: acreage === p ? '#eaf4ea' : '#fff', cursor: 'pointer',
              }}
            >
              {p}
            </button>
          ))}
          <input
            type="number" step="0.1" min="0.1" value={acreage}
            onChange={(e) => setAcreage(e.target.value)}
            style={{ width: 90, padding: 8, borderRadius: 8, border: '1px solid #ccc' }}
          />
        </div>

        {error && <p style={{ color: 'crimson' }}>{error}</p>}
        <button
          onClick={getAdvice} disabled={loading}
          style={{ marginTop: 8, padding: 12, width: '100%', borderRadius: 8, border: 'none', background: '#2e6b34', color: '#fff', fontWeight: 600, cursor: 'pointer' }}
        >
          {loading ? 'Calculating…' : 'Get Recommendations'}
        </button>
      </div>

      {result && (
        <div style={{ marginTop: 20 }}>
          <p style={{ color: '#555' }}>{result.description}</p>
          {result.recommendations.map((r) => (
            <div key={r.crop} style={{ background: '#fff', padding: 16, borderRadius: 10, marginBottom: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <strong>{r.crop}</strong>
                <span style={{ color: '#2e6b34', fontSize: 13, fontWeight: 600 }}>{r.suitability}</span>
              </div>
              <p style={{ margin: '6px 0 0', color: '#666' }}>
                Estimated yield for {acreage} acre(s): <strong>{r.estimatedYieldKg.toLocaleString()} kg</strong>
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
