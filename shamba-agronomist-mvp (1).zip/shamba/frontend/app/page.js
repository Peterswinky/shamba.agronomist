'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, setToken, setUser } from './lib/api';

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [form, setForm] = useState({ name: '', phone: '', password: '', role: 'FARMER', county: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const update = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const result =
        mode === 'login'
          ? await api.login({ phone: form.phone, password: form.password })
          : await api.register(form);
      setToken(result.token);
      setUser(result.user);
      router.push('/dashboard');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 420, margin: '60px auto', padding: 24, background: '#fff', borderRadius: 12, boxShadow: '0 2px 12px rgba(0,0,0,0.08)' }}>
      <h1 style={{ color: '#2e6b34' }}>🌾 Shamba Agronomist</h1>
      <p style={{ color: '#555' }}>Your digital farm advisor and marketplace.</p>

      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <button onClick={() => setMode('login')} style={tabStyle(mode === 'login')}>Log In</button>
        <button onClick={() => setMode('register')} style={tabStyle(mode === 'register')}>Register</button>
      </div>

      <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {mode === 'register' && (
          <input placeholder="Full name" value={form.name} onChange={update('name')} required style={inputStyle} />
        )}
        <input placeholder="Phone e.g. 0712345678" value={form.phone} onChange={update('phone')} required style={inputStyle} />
        <input placeholder="Password" type="password" value={form.password} onChange={update('password')} required style={inputStyle} />
        {mode === 'register' && (
          <>
            <select value={form.role} onChange={update('role')} style={inputStyle}>
              <option value="FARMER">I am a Farmer</option>
              <option value="BUYER">I am a Buyer</option>
            </select>
            <input placeholder="County" value={form.county} onChange={update('county')} style={inputStyle} />
          </>
        )}
        {error && <p style={{ color: 'crimson', fontSize: 14 }}>{error}</p>}
        <button disabled={loading} style={submitStyle}>
          {loading ? 'Please wait…' : mode === 'login' ? 'Log In' : 'Create Account'}
        </button>
      </form>
    </div>
  );
}

const tabStyle = (active) => ({
  flex: 1, padding: 10, borderRadius: 8, border: 'none', cursor: 'pointer',
  background: active ? '#2e6b34' : '#e6e6e6', color: active ? '#fff' : '#333',
});
const inputStyle = { padding: 10, borderRadius: 8, border: '1px solid #ccc', fontSize: 15 };
const submitStyle = { padding: 12, borderRadius: 8, border: 'none', background: '#2e6b34', color: '#fff', fontWeight: 600, cursor: 'pointer' };
