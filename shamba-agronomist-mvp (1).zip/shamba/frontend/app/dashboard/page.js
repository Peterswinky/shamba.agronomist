'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { getUser, clearToken } from '../lib/api';

export default function Dashboard() {
  const router = useRouter();
  const [user, setUserState] = useState(null);

  useEffect(() => {
    const u = getUser();
    if (!u) router.push('/');
    else setUserState(u);
  }, [router]);

  if (!user) return null;

  const farmerCards = [
    { href: '/soil-advisor', title: '🌱 Soil Advisor', desc: 'Get crop and yield recommendations for your soil type' },
    { href: '/disease-checker', title: '🔬 Disease Checker', desc: 'Photograph a leaf or soil sample for diagnosis' },
    { href: '/marketplace', title: '🛒 Sell Produce', desc: 'List your harvest for buyers to find' },
    { href: '/history', title: '📜 My History', desc: 'View all your past checks and listings' },
  ];

  const buyerCards = [
    { href: '/marketplace', title: '🛒 Browse Listings', desc: 'Find produce from farmers near you' },
    { href: '/history', title: '📜 My History', desc: 'View your inquiry history' },
  ];

  const cards = user.role === 'FARMER' ? farmerCards : buyerCards;

  return (
    <div style={{ maxWidth: 700, margin: '40px auto', padding: 24 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ color: '#2e6b34' }}>Karibu, {user.name} 👋</h1>
        <button
          onClick={() => { clearToken(); router.push('/'); }}
          style={{ border: 'none', background: 'transparent', color: '#c0392b', cursor: 'pointer' }}
        >
          Log out
        </button>
      </div>
      <p style={{ color: '#666' }}>{user.role === 'FARMER' ? 'Farmer' : 'Buyer'} dashboard</p>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 20 }}>
        {cards.map((c) => (
          <Link key={c.href} href={c.href} style={{ textDecoration: 'none' }}>
            <div style={{ background: '#fff', padding: 18, borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
              <h3 style={{ margin: '0 0 6px', color: '#2e6b34' }}>{c.title}</h3>
              <p style={{ margin: 0, color: '#666', fontSize: 14 }}>{c.desc}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
