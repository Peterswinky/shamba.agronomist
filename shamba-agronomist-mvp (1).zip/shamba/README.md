# 🌾 Shamba Agronomist — MVP

A production-ready platform for Kenyan farmers: soil-based crop advice, a photo-based
disease checker, a farmer/buyer produce marketplace, and a full activity history.

## Stack & why

| Layer | Choice | Why |
|---|---|---|
| API | Node.js + Express | Fast to ship, huge ecosystem, easy to hire for |
| DB | PostgreSQL + Prisma | Relational data (users/listings/inquiries), type-safe queries, painless migrations |
| Auth | JWT (phone + password) | Kenyan farmers log in by phone number, not email; stateless tokens scale horizontally |
| Frontend | Next.js (App Router) | SSR for fast first paint on low-end Android devices/slow networks, file-based routing |
| Uploads | Local disk (dev) → S3-compatible bucket (prod) | Disease-checker photos; swappable via `UPLOAD_DIR`/S3 env vars |
| CI/CD | GitHub Actions | Lint + test on every PR, build Docker image on merge to main |
| Containers | Docker + docker-compose | Identical dev/prod environments |

## Project layout

```
shamba/
├── backend/
│   ├── prisma/schema.prisma       # User, Listing, Inquiry, SoilCheck, DiseaseCheck, HistoryLog
│   └── src/
│       ├── config/                # env validation, prisma client
│       ├── middleware/            # JWT auth, role guard, error handler
│       ├── routes/                # auth, soil, disease, marketplace, history
│       ├── services/              # business logic (auth, history, disease inference)
│       ├── data/soilCropData.js   # soil type -> crop/yield lookup table
│       └── __tests__/             # Jest + Supertest
├── frontend/app/
│   ├── page.js                    # login / register
│   ├── dashboard/                 # role-aware home
│   ├── soil-advisor/
│   ├── disease-checker/
│   ├── marketplace/               # browse + list produce, inquiries
│   ├── history/                   # activity log
│   └── lib/api.js                 # typed fetch client + token storage
├── docker-compose.yml
└── .github/workflows/ci.yml
```

## Data model (summary)

- **User**: `id, name, phone (unique), email?, passwordHash, role (FARMER|BUYER), location, county`
- **Listing**: crop, quantityKg, pricePerKg, location, county, contactPhone, status (ACTIVE|SOLD|EXPIRED), farmerId
- **Inquiry**: listingId, buyerId, message — lets a farmer see which buyers are interested
- **SoilCheck / DiseaseCheck**: stored results tied to userId, feed the History screen
- **HistoryLog**: `userId, action, metadata (json), createdAt` — single audit trail for every user action (login, soil check, disease check, listing created, inquiry sent)

## API endpoints

```
POST   /api/auth/register            { name, phone, password, role, county }
POST   /api/auth/login               { phone, password }

GET    /api/soil/types
POST   /api/soil/advise              { soilType, acreage }   -> crops + yield estimates per acre/¼-acre

POST   /api/disease/check            multipart photo upload  -> diagnosis + confidence + advice

GET    /api/marketplace/listings                       ?crop=&county=&minQty=&maxPrice=  (public)
POST   /api/marketplace/listings                       farmer only
GET    /api/marketplace/listings/mine                  farmer only
PATCH  /api/marketplace/listings/:id/status             { status }  farmer only, own listing
POST   /api/marketplace/listings/:id/inquire             { message }  buyer only

GET    /api/history                                     paginated activity log for current user

POST   /api/payments/boost/:listingId                    farmer only — sends an M-Pesa STK push to pay for a 7-day listing boost
GET    /api/payments/:paymentId                          poll a payment's status
POST   /api/payments/mpesa/callback                       public — Safaricom's webhook, not called by the frontend

POST   /api/ussd                                          public — Africa's Talking USSD webhook (feature-phone menu)
```

All authenticated routes require `Authorization: Bearer <jwt>`. Role guards (`FARMER`/`BUYER`)
enforced server-side in middleware — never trust the client role.

## Setup (local dev)

```bash
# 1. Backend
cd shamba/backend
cp .env.example .env          # edit JWT_SECRET, DATABASE_URL
npm install
npx prisma migrate dev --name init
npm run dev                    # http://localhost:4000

# 2. Frontend (new terminal)
cd shamba/frontend
cp .env.example .env.local
npm install
npm run dev                    # http://localhost:3000

# Or run everything with Docker
cd shamba
docker compose up --build
```

## Testing

```bash
cd backend && npm test         # Jest + Supertest, auth flow + validation covered
```

## Deployment

1. **DB**: managed Postgres (Render, RDS, or Supabase) — set `DATABASE_URL`.
2. **API**: build the Docker image (`backend/Dockerfile`), deploy to Render/Fly.io/ECS. Run
   `npx prisma migrate deploy` as a release step before the app boots.
3. **Frontend**: deploy to Vercel (zero-config for Next.js) with `NEXT_PUBLIC_API_URL`
   pointing at the deployed API.
4. **File uploads**: switch `UPLOAD_DIR` for an S3-compatible bucket + signed URLs once you're
   off a single instance (local disk doesn't survive redeploys/horizontal scaling).
5. **CI/CD**: `.github/workflows/ci.yml` runs lint + tests on every PR; add a deploy job that
   triggers on merge to `main` once you've picked a host.

## Security notes

- Passwords hashed with bcrypt; JWT secret must be a long random string in prod (not the example value).
- All mutation routes validate input with Zod before touching the DB.
- Role checks happen server-side (`authorize('FARMER')` / `authorize('BUYER')`), not just hidden in the UI.
- Rate limiting on the API (`RATE_LIMIT_*` env vars) to blunt brute-force login attempts.
- CORS locked to `CORS_ORIGIN` — set this to your real frontend domain in prod.

## Disease checker: real vision model (Plant.id / Kindwise)

`DISEASE_MODEL_PROVIDER=plantid` calls the [Kindwise Plant.id v3 health assessment API](https://www.kindwise.com/handbook)
(`backend/src/services/disease.service.js`):

- Photo is uploaded via multer to disk, then read back as bytes and base64-encoded
  (fixed a bug where diskStorage doesn't populate `req.file.buffer` — we now `fs.readFile(req.file.path)`).
- Response's top disease suggestion (`name`, `probability`, `details.description`, `details.treatment`)
  is mapped into our `{ diagnosis, confidence, advice }` shape.
- **Graceful degradation**: if the Plant.id call fails or times out (15s), we fall back to the
  mock provider and flag the result as approximate, rather than failing the farmer's request outright.
  The failure is logged for monitoring/alerting.
- Soil photos aren't supported by Plant.id (it's plant/leaf-only), so `targetType=soil` always
  uses the mock heuristic — a real soil-composition model is a separate future integration.
- Get an API key at [admin.kindwise.com](http://admin.kindwise.com/), set `PLANT_ID_API_KEY`
  and `DISEASE_MODEL_PROVIDER=plantid`. Covered by `src/__tests__/disease.test.js` (mocked fetch).

## Payments: M-Pesa (Safaricom Daraja API)

Implemented as a **listing boost**: a farmer pays KES 20 via M-Pesa STK push to pin their
listing to the top of marketplace search for 7 days. Chosen over a marketplace-wide escrow/payment
system because it needs no trust between farmer and buyer to ship — it's a real revenue feature
that works day one, and the same `Payment` model/flow extends to future paid features
(subscriptions, buyer connection fees, produce escrow) without a schema rewrite.

- `backend/src/services/mpesa.service.js` — OAuth token fetch (cached in-memory; move to Redis
  once you run more than one instance) and STK Push initiation against the Daraja API.
- `backend/src/routes/payments.routes.js`:
  - `POST /api/payments/boost/:listingId` — farmer-only, creates a `Payment` row and triggers the
    STK push prompt on their phone.
  - `POST /api/payments/mpesa/callback` — public webhook Safaricom calls when the customer
    completes/cancels the prompt; on success, marks the payment `COMPLETED` and sets
    `Listing.boostedUntil`. Always responds `200` so Safaricom doesn't retry on our bugs.
- Marketplace browse (`GET /api/marketplace/listings`) ranks currently-active boosted listings
  above the rest, falling back to newest-first — an expired boost never outranks a fresh listing.
- **Setup**: register for [Safaricom Daraja sandbox credentials](https://developer.safaricom.co.ke),
  set `MPESA_CONSUMER_KEY`, `MPESA_CONSUMER_SECRET`, `MPESA_SHORTCODE`, `MPESA_PASSKEY`, and
  `MPESA_CALLBACK_URL` (must be a **public HTTPS URL** — use ngrok or similar for local testing,
  since Safaricom's sandbox needs to reach your callback).
- Covered by `src/__tests__/mpesa.test.js` (mocked fetch — phone normalization + STK push contract).

## USSD: feature-phone access (Africa's Talking)

`POST /api/ussd` (`backend/src/routes/ussd.routes.js`) implements a basic USSD menu so farmers
without smartphones/data can still reach the two highest-value flows by dialing a short code:

```
1. Soil & crop advice   → pick soil type, enter acreage, get top-3 crops + yield estimate
2. My marketplace listings → view your own active listings (requires an existing account)
3. Register / find my account → confirm phone is registered
```

Full marketplace browsing/listing creation stays app-only — USSD's ~182-character screen makes
anything beyond a quick lookup unusable. Menu logic reuses the same `getRecommendations()` used
by the app's soil advisor, so the numbers always match.

**Setup**: create a sandbox app at [account.africastalking.com](https://account.africastalking.com),
point its USSD callback URL at `https://your-api-domain.com/api/ussd`, and test with their
[USSD simulator](https://developers.africastalking.com/docs/ussd/overview) (no API key needed
for inbound webhook handling — only if you later call back into their API, e.g. to send SMS).

## What's still intentionally simple for MVP (next steps)

- No SMS notifications yet (e.g. "your listing got an inquiry") — a natural pairing with the
  USSD integration once Africa's Talking is already wired up.
- Boost payments aren't refunded/retried automatically on failure — a farmer whose STK push
  times out just tries again; a production version would add a manual admin retry path.
- M-Pesa OAuth token cache is in-process — fine for a single instance, move to Redis before
  scaling the API horizontally.
