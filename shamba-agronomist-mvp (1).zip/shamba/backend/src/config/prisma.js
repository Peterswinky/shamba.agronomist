const { PrismaClient } = require('@prisma/client');

// Singleton so we don't exhaust DB connections across hot reloads / requests.
const prisma = global.__prisma || new PrismaClient();
if (process.env.NODE_ENV !== 'production') global.__prisma = prisma;

module.exports = prisma;
