const express = require('express');
const prisma = require('../config/prisma');
const { VALID_SOIL_TYPES, getRecommendations } = require('../data/soilCropData');
const { logAction } = require('../services/history.service');

const router = express.Router();

// Africa's Talking USSD webhook. Docs: https://developers.africastalking.com/docs/ussd/overview
// AT POSTs application/x-www-form-urlencoded: { sessionId, serviceCode, phoneNumber, text }
// `text` accumulates the whole navigation path so far, e.g. "1*2*3", '' on first request.
// We respond "CON <menu>" to keep the session open, or "END <message>" to close it.
//
// This exists so farmers on basic/feature phones (no smartphone, no data bundle) can still
// reach the two highest-value flows — soil advice and checking their own listings — by
// dialing a short code. Full marketplace browsing/creation still requires the app, since
// USSD's 182-character screen makes anything more than a lookup unusable.

router.post('/', express.urlencoded({ extended: false }), async (req, res, next) => {
  try {
    const { phoneNumber, text = '' } = req.body;
    const steps = text.split('*').filter(Boolean);
    const response = await routeMenu(phoneNumber, steps);
    res.set('Content-Type', 'text/plain');
    res.send(response);
  } catch (err) {
    next(err);
  }
});

async function routeMenu(phoneNumber, steps) {
  // Step 0: root menu
  if (steps.length === 0) {
    return 'CON Welcome to Shamba Agronomist\n1. Soil & crop advice\n2. My marketplace listings\n3. Register / find my account';
  }

  const [choice1] = steps;

  // --- 1. Soil advisor: pick soil type, then acreage ---
  if (choice1 === '1') {
    if (steps.length === 1) {
      const options = VALID_SOIL_TYPES.map((t, i) => `${i + 1}. ${t}`).join('\n');
      return `CON Select your soil type:\n${options}`;
    }
    if (steps.length === 2) {
      const idx = Number(steps[1]) - 1;
      if (!VALID_SOIL_TYPES[idx]) return 'END Invalid soil type selected.';
      return 'CON Enter your land size in acres (e.g. 1 or 0.5):';
    }
    if (steps.length === 3) {
      const idx = Number(steps[1]) - 1;
      const soilType = VALID_SOIL_TYPES[idx];
      const acreage = parseFloat(steps[2]);
      if (!soilType || !acreage || acreage <= 0) return 'END Invalid input. Please try again.';

      const result = getRecommendations(soilType, acreage);
      const top = result.recommendations.slice(0, 3);
      const lines = top
        .map((c) => `${c.crop}: ~${Math.round(c.estimatedYieldKg)}kg`)
        .join('\n');

      const user = await findUserByPhone(phoneNumber);
      if (user) {
        await prisma.soilCheck.create({ data: { userId: user.id, soilType, acreage, result } });
        await logAction(user.id, 'SOIL_CHECK', { soilType, acreage, channel: 'USSD' });
      }

      return `END ${soilType} soil, ${acreage} acre(s). Best crops:\n${lines}\nFull details in the app.`;
    }
  }

  // --- 2. My listings: requires an existing registered farmer account ---
  if (choice1 === '2') {
    const user = await findUserByPhone(phoneNumber);
    if (!user) return 'END No account found for this number. Register via the Shamba Agronomist app first.';
    if (user.role !== 'FARMER') return 'END This feature is available for farmer accounts only.';

    const listings = await prisma.listing.findMany({
      where: { farmerId: user.id, status: 'ACTIVE' },
      orderBy: { createdAt: 'desc' },
      take: 5,
    });

    if (listings.length === 0) return 'END You have no active listings. Add one in the Shamba Agronomist app.';

    const lines = listings
      .map((l) => `${l.cropName}: ${l.quantityKg}kg @ KES${l.pricePerKg}/kg`)
      .join('\n');
    return `END Your active listings:\n${lines}`;
  }

  // --- 3. Account lookup ---
  if (choice1 === '3') {
    const user = await findUserByPhone(phoneNumber);
    if (!user) {
      return 'END No account found for this number. Download the Shamba Agronomist app or ask an agent to register you.';
    }
    return `END Registered as ${user.name} (${user.role}), ${user.county || 'county not set'}.`;
  }

  return 'END Invalid selection.';
}

// USSD phoneNumber arrives as "+2547XXXXXXXX"; our stored numbers are local "07XXXXXXXX".
function findUserByPhone(phoneNumber) {
  if (!phoneNumber) return null;
  const digits = phoneNumber.replace(/\D/g, '');
  const local = digits.startsWith('254') ? `0${digits.slice(3)}` : phoneNumber;
  return prisma.user.findUnique({ where: { phone: local } });
}

module.exports = router;
